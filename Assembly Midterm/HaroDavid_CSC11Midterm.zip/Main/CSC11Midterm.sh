echo "Launching CSC 11 Midterm: ./midterm"
./midterm
