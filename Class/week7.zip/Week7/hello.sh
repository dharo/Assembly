echo "This is executing The Lab for October 14"
echo "Hello World Program executing..."
./hello01
echo ""
echo "Read in number and output number executing..."
./printf01
echo ""
echo "Read in number and multiply it by 5 executing..."
echo "This file is split up into printf02.s and print02_f.s"
./printf02
